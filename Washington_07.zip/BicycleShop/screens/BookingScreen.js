import React, { useState } from "react";
import { View, Text, Button, StyleSheet, Switch } from "react-native";
import { RadioButton } from "react-native-paper";
import Colors from "../constants/colors";

export default function BookingScreen({
  services,
  toggleServiceHandler,
  repairTimeRadioButtons,
  newsletter,
  rentalMembership,
  onToggleNewsletter,
  onToggleRental,
  onReviewOrder,
  repairTimeId,
  onSetRepairTimeId,
}) {
  const [step, setStep] = useState(0);
  // locates repair time by using id. Use parent state for selected repair time
  const selectedRepairTimeId = repairTimeId;

  const nextStep = () => setStep((item) => item + 1);

  if (step === 0) {
    // Service Selection Screen
    return (
      <View style={styles.container}>
        {/*Title for section*/}
        <Text style={styles.title}>Select Your Services</Text>
        {services.map((item) => (
          <View key={item.id} style={styles.row}>
            <Text>
              {item.name} - ${item.price}
            </Text>
            <Switch
              value={item.value}
              onValueChange={() => toggleServiceHandler(item.id)}
            />
          </View>
        ))}
        <Button
          title="Next: Choose Time"
          color={Colors.primary500}
          onPress={nextStep}
        />
      </View>
    );
  }
  if (step === 1) {
    // Repair Screen
    return (
      <View style={styles.container}>
        {/*Title for section*/}
        <Text style={styles.title}>Select Repair Time</Text>
        {repairTimeRadioButtons.map((r) => (
          <View key={r.id} style={styles.row}>
            <Text>
              {r.label} (+${r.price})
            </Text>
            <RadioButton
              value={r.id}
              status={selectedRepairTimeId === r.id ? "checked" : "unchecked"} // just checks off if selected
              onPress={() => onSetRepairTimeId(r.id)} // sets selected option choice when clcke
              color={Colors.primary500} // radio button color
            />
          </View>
        ))}
        <Button
          title="Next: Extras"
          color={Colors.primary500}
          onPress={nextStep}
        />
      </View>
    );
  }
  if (step === 2) {
    // Optional extras screen
    return (
      <View style={styles.container}>
        {/*Title for section*/}
        <Text style={styles.title}>Optional Extras</Text>

        <View style={styles.row}>
          <Text>Subscribe to Newsletter (Free)</Text>
          <Switch value={newsletter} onValueChange={onToggleNewsletter} />
        </View>

        <View style={styles.row}>
          <Text>Join Rental Membership (+$100)</Text>
          <Switch value={rentalMembership} onValueChange={onToggleRental} />
        </View>

        <Button
          title="Review Order"
          color={Colors.primary500}
          onPress={() => onReviewOrder(selectedRepairTimeId)}
        />
      </View>
    );
  }
  return null;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
  },
  title: {
    fontSize: 40,
    fontFamily: "Note",
    marginBottom: 15,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8,
  },
});
