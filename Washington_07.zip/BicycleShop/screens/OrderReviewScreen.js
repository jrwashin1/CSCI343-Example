import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StyleSheet, View, ScrollView, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

import Colors from "../constants/colors";
import NavButton from "../components/NavButton";

export default function OrderReviewScreen(props) {
  const insets = useSafeAreaInsets();
  // Get selected repair time and price, || sets default values when not
  const selectedRepairTime = props.repairTime || "";
  const selectedRepairTimePrice = props.repairTimePrice || 0;

  // Get selected services
  const activeServices = props.services
    ? props.services.filter((service) => service.value)
    : [];
  // Calculate the total price of selected services
  let servicesTotal = 0;
  for (let i = 0; i < activeServices.length; i++) {
    servicesTotal += activeServices[i].price;
  }
  // Add $100 if rental membership is selected, otherwise $0
  const rentalMembershipTotal = props.rentalMembership ? 100 : 0;
  // Subtotal is the sum of services, repair time, and rental membership
  const subtotal =
    servicesTotal + selectedRepairTimePrice + rentalMembershipTotal;
  // Calculate 6% sales tax on subtotal
  const tax = subtotal * 0.06;
  // Total is subtotal plus tax
  const total = subtotal + tax;

  return (
    <LinearGradient
      colors={[Colors.primary800, Colors.accent500, Colors.primary500]}
      style={styles.container}
    >
      <View style={styles.inner}>
        <Text style={styles.title}>Order Summary</Text>
        <View style={styles.row}>
          <Text style={styles.detail}>Repair Time:</Text>
          <Text style={styles.subDetail}>{selectedRepairTime}</Text>
          <Text style={styles.subDetail}>
            ${selectedRepairTimePrice.toFixed(2)}
          </Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.detail}>Services:</Text>
        </View>
        {activeServices.length === 0 ? (
          <View style={styles.row}>
            <Text style={styles.subDetail}>No services selected</Text>
          </View>
        ) : (
          activeServices.map((item) => (
            <View key={item.id} style={styles.row}>
              <Text style={styles.subDetail}>
                {item.name} - ${item.price.toFixed(2)}
              </Text>
            </View>
          ))
        )}
        <View style={styles.row}>
          <Text style={styles.detail}>Extras:</Text>
        </View>
        {props.newsletter && (
          <View style={styles.row}>
            <Text style={styles.subDetail}>Newsletter Subscription</Text>
          </View>
        )}
        {props.rentalMembership && (
          <View style={styles.row}>
            <Text style={styles.subDetail}>Rental Membership (+$100.00)</Text>
          </View>
        )}
        {!props.newsletter && !props.rentalMembership && (
          <View style={styles.row}>
            <Text style={styles.subDetail}>No extras selected</Text>
          </View>
        )}
        <View style={styles.row}>
          <Text style={styles.detail}>Order Breakdown:</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.subDetail}>
            Services Total: ${servicesTotal.toFixed(2)}
          </Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.subDetail}>
            Repair Time: ${selectedRepairTimePrice.toFixed(2)}
          </Text>
        </View>
        {props.rentalMembership && (
          <View style={styles.row}>
            <Text style={styles.subDetail}>Rental Membership: $100.00</Text>
          </View>
        )}
        <View style={styles.row}>
          <Text style={styles.subDetail}>Subtotal: ${subtotal.toFixed(2)}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.subDetail}>
            Sales Tax (6%): ${tax.toFixed(2)}
          </Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.subDetail}>Total: ${total.toFixed(2)}</Text>
        </View>
        <View style={styles.row}>
          <NavButton onPress={props.onNext}>Return Home</NavButton>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
  },
  inner: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 40,
    fontFamily: "Note",
    marginBottom: 15,
    color: Colors.primary500,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8,
    width: "100%",
  },
  detail: {
    fontSize: 20,
    color: Colors.primary500,
    fontFamily: "Note",
  },
  subDetail: {
    textAlign: "center",
    fontSize: 20,
    color: Colors.primary500,
    fontWeight: "bold",
    marginVertical: 2,
  },
});
