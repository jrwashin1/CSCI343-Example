import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  ImageBackground,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { RadioGroup } from "react-native-radio-buttons-group";
import BouncyCheckbox from "react-native-bouncy-checkbox";
import Colors from "../constants/colors";
import Title from "../components/Title";
import NavButton from "../components/NavButton";

export default function HomeScreen(props) {
  const insets = useSafeAreaInsets();

  return (
    <ImageBackground
      source={require("../assets/images/bike_background.jpg")}
      resizeMode="cover"
      style={styles.container}
    >
      <View
        style={[
          styles.innerContainer,
          {
            paddingTop: insets.top,
            paddingBottom: insets.bottom,
          },
        ]}
      >
        <View style={styles.titleContainer}>
          <Title>Bicycle Repair Shop</Title>
        </View>

        <ScrollView style={styles.scrollContainer}>
          {/* Service Time */}
          <View style={styles.radioContainer}>
            <Text style={styles.header}>Service Time:</Text>
            <RadioGroup
              radioButtons={props.repairTimeRadioButtons}
              onPress={props.onSetRepairTimeId}
              selectedId={props.repairTimeId}
              layout="row"
            />
          </View>

          {/* Services */}
          <View style={styles.servicesContainer}>
            <Text style={styles.header}>Service Options:</Text>
            {props.services.map((item) => (
              <BouncyCheckbox
                key={item.id}
                text={`${item.name} ($${item.price})`}
                onPress={() => props.onToggleService(item.id)}
                fillColor={Colors.primary500}
                textStyle={styles.checkBoxText}
              />
            ))}
          </View>

          {/* switches */}
          <View style={styles.switchContainer}>
            <Text style={styles.header}>Extras:</Text>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>Newsletter Signup ($0)</Text>
              <Switch
                onValueChange={props.onToggleNewsletter}
                value={props.newsletter}
                thumbColor={props.newsletter ? Colors.primary500 : "#ccc"}
              />
            </View>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>Rental Membership ($100)</Text>
              <Switch
                onValueChange={props.onToggleRental}
                value={props.rentalMembership}
                thumbColor={props.rentalMembership ? Colors.primary500 : "#ccc"}
              />
            </View>
          </View>

          <View style={styles.buttonContainer}>
            <NavButton onPress={props.onNext}>Submit Order</NavButton>
          </View>
        </ScrollView>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: "100%",
  },
  innerContainer: {
    flex: 1,
    alignItems: "center",
  },
  titleContainer: {
    fontSize: 40,
    marginTop: 20,
    borderWidth: 2,
    borderRadius: 5,
    borderColor: Colors.primary500,
    paddingHorizontal: 30,
  },
  scrollContainer: {
    width: "90%",
  },
  header: {
    fontSize: 25,
    fontFamily: "Note",
    color: Colors.primary500,
    textAlign: "center",
    marginVertical: 8,
  },
  checkBoxText: {
    fontFamily: "Note",
    color: Colors.primary500,
  },
  servicesContainer: {
    marginBottom: 20,
  },
  switchContainer: {
    marginTop: 10,
    marginBottom: 20,
  },
  switchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginHorizontal: 10,
    marginVertical: 5,
  },
  switchLabel: {
    fontFamily: "Note",
    color: Colors.primary500,
  },
  buttonContainer: {
    alignItems: "center",
    marginVertical: 20,
  },
});
