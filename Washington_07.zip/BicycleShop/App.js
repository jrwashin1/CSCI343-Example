import { useEffect, useState, useMemo } from "react";
import { StyleSheet } from "react-native";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import * as SplashScreen from "expo-splash-screen";
import * as Font from "expo-font";

import Colors from "./constants/colors";
import BookingScreen from "./screens/BookingScreen";
import OrderReviewScreen from "./screens/OrderReviewScreen";

// Keep the splash screen visible while we fetch resources
SplashScreen.preventAutoHideAsync();

export default function App() {
  // Load fonts, Splashscreen
  const [loaded] = Font.useFonts({
    Note: require("./assets/fonts/Note.ttf"),
  });

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  // Handling state
  const [currentScreen, setCurrentScreen] = useState("");
  const [currentPrice, setCurrentPrice] = useState(0);

  // Memoize radio button data so it doesn't get recreated on every render
  const repairTimeRadioButtons = useMemo(
    () => [
      {
        id: 0,
        label: "Standard",
        value: "Standard",
        price: 0,
        borderColor: Colors.primary500,
        color: Colors.primary500,
      },
      {
        id: 1,
        label: "Expedited",
        value: "Expedited",
        price: 50,
        borderColor: Colors.primary500,
        color: Colors.primary500,
      },
      {
        id: 2,
        label: "Next Day",
        value: "Next Day",
        price: 100,
        borderColor: Colors.primary500,
        color: Colors.primary500,
      },
    ],
    []
  );
  const [repairTimeId, setRepairTimeId] = useState(0);

  const services = useMemo(
    () => [
      { id: 0, name: "Basic Tune-Up", value: false, price: 50 },
      { id: 1, name: "Comprehensive Tune-Up", value: false, price: 75 },
      { id: 2, name: "Flat Tire Repair", value: false, price: 20 },
      { id: 3, name: "Brake Servicing", value: false, price: 50 },
      { id: 4, name: "Gear Servicing", value: false, price: 40 },
      { id: 5, name: "Chain Servicing", value: false, price: 15 },
      { id: 6, name: "Frame Repair", value: false, price: 35 },
      { id: 7, name: "Safety Check", value: false, price: 25 },
      { id: 8, name: "Accessory Install", value: false, price: 10 },
    ],
    []
  );
  const [serviceState, setServiceState] = useState(services);

  // switches
  const [newsletter, setNewsletter] = useState(false);
  const [rentalMembership, setRentalMembership] = useState(false);

  // Handlers
  function setRepairTimeHandler(id) {
    setRepairTimeId(id);
  }

  function setServiceHandler(id) {
    setServiceState((prev) =>
      prev.map((s) => (s.id === id ? { ...s, value: !s.value } : s))
    );
  }

  function setNewsletterHandler() {
    setNewsletter((prev) => !prev);
  }

  function setRentalMembershipHandler() {
    setRentalMembership((prev) => !prev);
  }

  // Reset all state to initial values and go to home screen
  function homeScreenHandler() {
    setCurrentPrice(0);
    setRepairTimeId(0);
    setServiceState(services.map((item) => ({ ...item, value: false })));
    setNewsletter(false);
    setRentalMembership(false);
    setCurrentScreen("");
  }

  // Calculate price and go to review
  function orderReviewHandler() {
    let price = 0;
    for (let i = 0; i < serviceState.length; i++) {
      if (serviceState[i].value) {
        price = price + serviceState[i].price;
      }
    }
    price = price + repairTimeRadioButtons[repairTimeId].price;
    if (rentalMembership) price = price + 100;
    setCurrentPrice(price);
    setCurrentScreen("review");
  }

  // Choose screen
  let screen = (
    <BookingScreen
      services={serviceState}
      toggleServiceHandler={setServiceHandler}
      repairTimeRadioButtons={repairTimeRadioButtons}
      repairTimeId={repairTimeId}
      onSetRepairTimeId={setRepairTimeHandler}
      newsletter={newsletter}
      rentalMembership={rentalMembership}
      onToggleNewsletter={setNewsletterHandler}
      onToggleRental={setRentalMembershipHandler}
      onReviewOrder={orderReviewHandler}
    />
  );

  // If the user is on the review screen, show the OrderReviewScreen
  if (currentScreen === "review") {
    screen = (
      <OrderReviewScreen
        repairTime={repairTimeRadioButtons[repairTimeId].value}
        repairTimePrice={repairTimeRadioButtons[repairTimeId].price}
        services={serviceState}
        newsletter={newsletter}
        rentalMembership={rentalMembership}
        price={currentPrice}
        onNext={homeScreenHandler}
      />
    );
  }

  // rendering screens based on state
  if (!loaded) {
    return null;
  }

  return (
    <>
      <StatusBar style="light" />
      <SafeAreaProvider style={styles.container}>{screen}</SafeAreaProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.accent500,
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
});
