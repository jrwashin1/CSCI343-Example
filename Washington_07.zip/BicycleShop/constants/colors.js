const Colors = {
  accent500: "#21529cff",
  primary300: "#ffffff",
  primary500: "#f9a616ff",
  primary800: "#000000",
};

export default Colors;
