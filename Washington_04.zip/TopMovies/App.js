import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View, FlatList } from 'react-native';
import Movie from './assets/components/Movie';

export default function App() {
  const [movieItems, setMovieItems] = useState([
    {
      id: "1",
      title: "Friday",
      image: require("./assets/images/friday.jpg"),
      rating: "9.0",
    },
    {
      id: "2",
      title: "The Dark Knight",
      image: require("./assets/images/darkknight.jpg"),
      rating: "8.9",
    },
    {
      id: "3",
      title: "Rush Hour",
      image: require("./assets/images/rushhour.jpg"),
      rating: "9.0",
    },
    {
      id: "4",
      title: "Toy Story",
      image: require("./assets/images/toystory.jpg"),
      rating: "8.7",
    },
    {
      id: "5",
      title: "The Matrix",
      image: require("./assets/images/matrix.jpg"),
      rating: "9.2",
    },
    {
      id: "6",
      title: "The Hunger Games",
      image: require("./assets/images/hungergames.jpg"),
      rating: "8.9",
    },
    {
      id: "7",
      title: "Deadpool",
      image: require("./assets/images/deadpool.jpg"),
      rating: "9.1",
    },
    {
      id: "8",
      title: "Black Panther",
      image: require("./assets/images/blackpanther.jpg"),
      rating: "9.3",
    },
    {
      id: "9",
      title: "Wakanda Forever",
      image: require("./assets/images/wakandaforever.jpg"),
      rating: "8.1",
    },
    {
      id: "10",
      title: "Space Jam",
      image: require("./assets/images/spacejam.jpg"),
      rating: "9.3",
    },
  ]);

  return (
    <>
      <StatusBar style="dark" />
      <SafeAreaView style={styles.rootContainer}>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>Top 10 Movies</Text>
        </View>

        <View style={styles.listContainer}>
          <FlatList
            data={movieItems}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <Movie 
                title={item.title} 
                image={item.image} 
                rating={item.rating}
                />
            )}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    backgroundColor: 'teal',
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    justifyContent: 'center',
    marginVertical: 20,
    paddingHorizontal: 10,
    borderWidth: 3,
    borderRadius: 10,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  listContainer: {
    flex: 10,
    width: '90%',
  },
});
