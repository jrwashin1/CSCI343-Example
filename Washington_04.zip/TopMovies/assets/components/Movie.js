import { StyleSheet, Text, View, Image } from 'react-native';

export default function Movie(props) { 
    return (
        <View style={styles.itemContainer}>
            <View style={styles.itemTitleContainer}>
                <Text style={styles.itemTitle}>{props.title}</Text>
            </View>
            <View style={styles.imageContainer}>
                <Image 
                    style={styles.image}
                    source={props.image} 
                />
            </View>
            <View style={styles.ratingContainer}>
                <Text style={styles.rating}>{props.rating} / 10</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    itemContainer: {
        marginBottom: 20,
    },
    itemTitleContainer: {
        backgroundColor: '#fefefe',
        borderWidth: 3,
        borderRadius: 5,
        marginBottom: 5,
        padding: 5,
    },
    itemTitle: {
        fontSize: 25,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    imageContainer: {
        alignItems: 'center',
        borderWidth: 2,
        borderRadius: 5,
        overflow: 'hidden',
        marginBottom: 5,
    },
    image: {
        width: "100%",
        height: 220,
        resizeMode: "cover",
    },
    ratingContainer: {
        backgroundColor: '#fefefe',
        borderWidth: 2,
        borderRadius: 5,
        padding: 5,
    },
    rating: {
        fontSize: 22,
        textAlign: 'center',
    },
});
