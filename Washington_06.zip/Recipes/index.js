import 'react-native-gesture-handler';
import { registerRootComponent } from 'expo';

import App from './App';

// registerRootComponent wires the app into the native runtime
registerRootComponent(App);
