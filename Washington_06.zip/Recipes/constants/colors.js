const colors = {
  primary: '#0085CA',
  black: '#000000',
  silver: '#A5ACAF',
  white: '#FFFFFF',
  accent: '#0085CA',
};

export default colors;
