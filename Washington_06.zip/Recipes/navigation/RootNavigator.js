import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import HomeScreen from "../screens/HomeScreen";
import RecipesScreen from "../screens/RecipesScreen";
import AddRecipeScreen from "../screens/AddRecipeScreen";
import ViewRecipeModal from "../screens/ViewRecipeModal";

// Navigation structure:
// MainStack: regular push/pop stack (Home, Recipes, AddRecipe)
// RootStack: wraps MainStack and presents the recipe viewer as a modal
// This keeps modal styling separate from the main navigation flow.

const MainStack = createStackNavigator();
const RootStack = createStackNavigator();

function MainStackScreen({ recipes, deleteRecipe, addRecipe }) {
  return (
    <MainStack.Navigator>
      <MainStack.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: "Home" }}
      />
      <MainStack.Screen name="Recipes">
        {(props) => (
          <RecipesScreen
            {...props}
            recipes={recipes}
            deleteRecipe={deleteRecipe}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="AddRecipe">
        {(props) => <AddRecipeScreen {...props} addRecipe={addRecipe} />}
      </MainStack.Screen>
    </MainStack.Navigator>
  );
}

export default function RootNavigator({ recipes, deleteRecipe, addRecipe }) {
  return (
    // Use `presentation: 'modal' so the viewer appears above the main stack.
    <RootStack.Navigator screenOptions={{ presentation: "modal" }}>
      <RootStack.Screen
        name="Main"
        options={{ headerShown: false }}
      >
        {(props) => (
          <MainStackScreen
            {...props}
            recipes={recipes}
            deleteRecipe={deleteRecipe}
            addRecipe={addRecipe}
          />
        )}
      </RootStack.Screen>
      <RootStack.Screen
        name="ViewRecipeModal"
        component={ViewRecipeModal}
        options={{
          headerShown: false,
          // cardStyle may be version-specific; for a translucent backdrop we style the modal itself
          cardStyle: { backgroundColor: "rgba(0,0,0,0.3)" },
        }}
      />
    </RootStack.Navigator>
  );
}
