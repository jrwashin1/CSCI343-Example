import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import colors from "../constants/colors";

// Small presentational component for a recipe row. It receives the recipe `item` and two callbacks: `onView` (open viewer) and `onDelete`.

export default function RecipeItem({ item, onView, onDelete }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{item.title}</Text>
      <View style={styles.buttons}>
        {/* View shows the modal with the recipe data */}
        <Button title="View" color={colors.primary} onPress={() => onView(item)} />
        {/* Delete calls back into parent to remove the recipe */}
        <Button title="Delete" color={colors.silver} onPress={() => onDelete(item.id)} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.silver,
    alignItems: "center",
    backgroundColor: colors.white,
  },
  title: {
    flex: 1,
    fontSize: 20,
    color: colors.black,
  },
  buttons: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: 120,
    marginBottom: 10
  },
});
