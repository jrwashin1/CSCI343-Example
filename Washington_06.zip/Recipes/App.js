import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import RootNavigator from "./navigation/RootNavigator";

// manages recipe state and connects it into navigation stores recipes and passes handlers

export default function App() {
  const [recipes, setRecipes] = useState([]);

  const addRecipe = (title, text) => {
    const newRecipe = {
      id: Date.now().toString(),
      title,
      text,
    };
    setRecipes((prev) => [...prev, newRecipe]);
  };

  const deleteRecipe = (id) => {
    setRecipes((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <NavigationContainer>
      <RootNavigator
        recipes={recipes}
        deleteRecipe={deleteRecipe}
        addRecipe={addRecipe}
      />
    </NavigationContainer>
  );
}
