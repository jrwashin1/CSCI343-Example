import React, { useState } from "react";
import { View, TextInput, Button, Alert, StyleSheet } from "react-native";
import colors from "../constants/colors";

// Simple form for adding a recipe. Form state is local; on successful save this screen calls `addRecipe` (from props) and navigates back.

export default function AddRecipeScreen({ navigation, addRecipe }) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");

  const handleSave = () => {
    if (!title.trim() || !text.trim()) {
      Alert.alert("Error", "Please fill both title and recipe text.");
      return;
    }
    addRecipe(title, text);
    navigation.goBack();
  };

  const handleCancel = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Recipe Title"
        style={styles.input}
        value={title}
        onChangeText={setTitle}
      />
      <TextInput
        placeholder="Recipe Text"
        style={[styles.input, { height: 120 }]}
        value={text}
        onChangeText={setText}
        multiline
      />
      <View style={styles.buttonRow}>
        <Button title="Save" color={colors.primary} onPress={handleSave} />
        <Button title="Cancel" color={colors.silver} onPress={handleCancel} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: colors.white },
  input: {
    borderWidth: 1,
    borderColor: colors.silver,
    borderRadius: 6,
    padding: 10,
    marginVertical: 8,
    backgroundColor: colors.white,
    color: colors.black,
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 20,
  },
});

