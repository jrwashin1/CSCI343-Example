import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import colors from "../constants/colors";

// Modal used to display a single recipe. The modal uses a semi-opaque backdrop and a bordered inner card so the content stands out from the app.

export default function ViewRecipeModal({ route, navigation }) {
  const recipe = route && route.params && route.params.recipe;

  if (!recipe) {
    return (
      <View style={styles.backdrop}>
        <View style={styles.modal}>
          <Text style={styles.title}>No recipe</Text>
          <Text style={styles.body}>No recipe data was provided.</Text>
          {/* Close the modal and return to the previous screen */}
          <Button title="Close" color={colors.primary} onPress={() => navigation.goBack()} />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.backdrop}>
      <View style={styles.modal}>
        <Text style={styles.title}>{recipe.title}</Text>
        <Text style={styles.body}>{recipe.text}</Text>
        <Button title="Close" onPress={() => navigation.goBack()} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "#00000099",
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    width: "85%",
    backgroundColor: colors.white,
    borderRadius: 10,
    padding: 20,
    borderColor: colors.primary,
    borderWidth: 2,
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 12,
    color: colors.primary,
  },
  body: {
    fontSize: 16,
    marginBottom: 20,
    color: colors.black,
  },
});
