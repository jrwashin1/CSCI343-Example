import React from "react";
import { View, Text, Button, Image, StyleSheet } from "react-native";
import colors from "../constants/colors";

// Simple launch screen that shows a hero image and a button to view recipes.

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>The Recipe App</Text>
      <Image
        source={require("../assets/images/ingredients.jpg")}
        style={styles.image}
        resizeMode="cover"
      />
      <Button
        title="View Recipes"
        onPress={() => navigation.navigate("Recipes")}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: colors.accent,
  },
  title: {
    fontSize: 50,
    fontWeight: "bold",
    marginBottom: 20,
    color: colors.white,
    textAlign: 'center'
  },
  image: {
    width: 350,
    height: 200,
    borderRadius: 8,
    marginBottom: 20,
  },
});
