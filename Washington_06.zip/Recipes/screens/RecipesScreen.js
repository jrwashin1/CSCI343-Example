import React from "react";
import { View, FlatList, Button, StyleSheet, Text } from "react-native";
import RecipeItem from "../components/RecipeItem";
import colors from "../constants/colors";

// Screen that lists recipes. If there are none it shows an empty state. Tapping a recipe opens the `ViewRecipeModal` via navigation with params.

export default function RecipesScreen({ navigation, recipes, deleteRecipe }) {
  const onView = (recipe) => {
    // navigate to modal screen, passing recipe
    navigation.navigate("ViewRecipeModal", { recipe });
  };

  return (
    <View style={styles.container}>
      {recipes.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No recipes added yet.</Text>
        </View>
      ) : (
        <FlatList
          data={recipes}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <RecipeItem item={item} onView={onView} onDelete={deleteRecipe} />
          )}
        />
      )}
      <View style={styles.footer}>
        <View style={styles.footerButton}>
          <Button
            title="Add Recipe"
            color={colors.primary}
            onPress={() => navigation.navigate("AddRecipe")}
          />
        </View>
        <View style={styles.footerButton}>
          <Button title="Home" color={colors.silver} onPress={() => navigation.navigate("Home")} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.white },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyText: {
    color: colors.primary,
    fontSize: 18,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    backgroundColor: colors.accent,
  },
  footerButton: {
    flex: 1,
    marginHorizontal: 8,
  },
});
