import React, { useState } from "react";
import { SafeAreaView, StyleSheet, Text, TextInput, View, Button, Modal } from "react-native";
import { StatusBar } from "expo-status-bar";

const responses = [
  "It is certain",
  "It is decidedly so",
  "Without a doubt",
  "Yes definitely",
  "You may rely on it",
  "As I see it, yes",
  "Most likely",
  "Outlook good",
  "Yes",
  "Signs point to yes",
  "Reply hazy, try again",
  "Ask again later",
  "Better not tell you now",
  "Cannot predict now",
  "Concentrate and ask again",
  "Don't count on it",
  "My reply is no",
  "My sources say no",
  "Outlook not so good",
  "Very doubtful"
];

export default function App() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [showModal, setShowModal] = useState(false);

  const askEightBall = () => {
    if (!question.trim()) {
      setAnswer("Test the knowledge of the 8 Ball!");
    } else {
      const random = Math.floor(Math.random() * responses.length);
      setAnswer(responses[random]);
    }
    setShowModal(true);
  };

  return (
    <>
      <StatusBar style="default" />
      <SafeAreaView style={styles.container}>
        <Text style={styles.title}>Magic 8 Ball</Text>

        <TextInput
          style={styles.input}
          placeholder="Ask your question here"
          placeholderTextColor="#dfdfdfff"
          value={question}
          onChangeText={setQuestion}
        />

        <View style={styles.button}>
          <Button title="CLICK TO ASK THE BALL" color="#A27752" onPress={askEightBall} />
        </View>

        <Modal visible={showModal} animationType="slide" transparent={false}>
          <SafeAreaView style={styles.modal}>
            <Text style={styles.response}>You Asked:</Text>
            <Text style={styles.text}>{question}</Text>

            <Text style={styles.response}>The 8 Ball Says...</Text>
            <Text style={styles.answer}>{answer}</Text>

            <View style={styles.button}>
              <Button title="Ask Again." color="#A27752" onPress={() => setShowModal(false)} />
            </View>
          </SafeAreaView>
        </Modal>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#006F71",
    padding: 20,
    alignItems: "center",
  },
  title: {
    fontSize: 36,
    color: "black",
    fontWeight: "bold",
    marginTop: 60,
    marginBottom: 40,
  },
  input: {
    width: "100%",
    fontSize: 18,
    padding: 12,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    backgroundColor: "white",
    marginBottom: 20,
  },
  button: {
    width: "60%",
    marginTop: 10,
  },
  modal: {
    flex: 1,
    backgroundColor: "#006F71",
    alignItems: "center",
    padding: 20,
  },
  response: {
    fontSize: 20,
    color: "white",
    marginTop: 30,
    marginBottom: 10,
    fontWeight: "600",
  },
  text: {
    fontSize: 18,
    color: "white",
    marginBottom: 20,
    textAlign: "center",
  },
  answer: {
    fontSize: 24,
    color: "yellow",
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 30,
  },
});
