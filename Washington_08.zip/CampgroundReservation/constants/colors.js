const Colors = {
  accent300: "#FFA500",
  accent500: "#FF8C00",
  primary300o5: "rgba(245, 222, 179, 0.8)",
  primary300: "#F5DEB3",
  primary500: "#8B4513",
  primary800: "#654321",
  campgroundGreen: "#A0522D",
  campgroundBrown: "#654321",
  campgroundTan: "#D2B48C",
};

export default Colors;
