const Colors = {
  accent300: "rgb(135, 206, 235)",
  accent300o75: "rgba(135, 207, 235, 0.75)",
  accent500: "rgb(255, 193, 7)",
  accent800: "rgb(66, 165, 245)",
  primary300: "rgb(255, 248, 225)",
  primary500: "rgb(30, 58, 138)",
  primary800: "rgb(15, 23, 42)",
};

export default Colors;
