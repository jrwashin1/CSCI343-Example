import Country from "../models/countries";
import Destination from "../models/destinations";

export const COUNTRIES = [
  new Country("c1", "Japan", "#e91e63"), // Pink
  new Country("c2", "France", "#2196f3"), // Blue
  new Country("c3", "Italy", "#4caf50"), // Green
  new Country("c4", "Greece", "#ff9800"), // Orange
  new Country("c5", "Thailand", "#9c27b0"), // Purple
  new Country("c6", "Egypt", "#ffeb3b"), // Yellow
  new Country("c7", "Australia", "#03a9f4"), // Light Blue
  new Country("c8", "Brazil", "#8bc34a"), // Light Green
  new Country("c9", "Iceland", "#ff5722"), // Deep Orange
  new Country("c10", "Morocco", "#673ab7"), // Deep Purple
];

export const DESTINATIONS = [
  // Japan destinations
  new Destination(
    "d1",
    "c1",
    "Tokyo",
    3500,
    1457,
    4.8,
    "A bustling metropolis blending traditional culture with cutting-edge technology. Experience ancient temples, modern skyscrapers, incredible cuisine, and vibrant neighborhoods.",
    "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&q=80"
  ),
  new Destination(
    "d2",
    "c1",
    "Kyoto",
    2800,
    794,
    4.9,
    "Ancient capital of Japan featuring over 2,000 temples and shrines. Known for traditional architecture, geisha districts, and beautiful cherry blossoms.",
    "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800&q=80"
  ),

  // France destinations
  new Destination(
    "d3",
    "c2",
    "Paris",
    4200,
    250,
    4.7,
    "The City of Light, famous for the Eiffel Tower, Louvre Museum, Notre-Dame Cathedral, and world-class cuisine. A center of art, fashion, and romance.",
    "https://images.unsplash.com/photo-1431274172761-fca41d930114?w=800&q=80"
  ),
  new Destination(
    "d4",
    "c2",
    "Nice",
    3100,
    350,
    4.5,
    "Stunning coastal city on the French Riviera with beautiful beaches, luxury resorts, and the famous Promenade des Anglais. Perfect Mediterranean getaway.",
    "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=800&q=80"
  ),

  // Italy destinations
  new Destination(
    "d5",
    "c3",
    "Rome",
    2900,
    753,
    4.6,
    "The Eternal City, home to the Colosseum, Vatican City, and countless historical monuments. Experience millennia of history, art, and incredible Italian cuisine.",
    "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800&q=80"
  ),
  new Destination(
    "d6",
    "c3",
    "Venice",
    3800,
    421,
    4.4,
    "Unique floating city built on canals, famous for gondola rides, St. Mark's Square, and stunning architecture. A romantic destination like no other.",
    "https://images.unsplash.com/photo-1514890547357-a9ee288728e0?w=800&q=80"
  ),

  // Greece destinations
  new Destination(
    "d7",
    "c4",
    "Santorini",
    3600,
    1500,
    4.8,
    "Breathtaking volcanic island with white-washed buildings, blue-domed churches, and spectacular sunsets. Famous for its wine and dramatic clifftop views.",
    "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&q=80"
  ),
  new Destination(
    "d8",
    "c4",
    "Athens",
    2400,
    3400,
    4.3,
    "Cradle of democracy and birthplace of philosophy. Home to the iconic Acropolis, Parthenon, and numerous ancient ruins that shaped Western civilization.",
    "https://images.unsplash.com/photo-1555993539-1732b0258235?w=800&q=80"
  ),

  // Thailand destinations
  new Destination(
    "d9",
    "c5",
    "Bangkok",
    1800,
    1782,
    4.5,
    "Vibrant capital city known for ornate temples, floating markets, bustling street life, and incredible street food. A perfect blend of tradition and modernity.",
    "https://images.unsplash.com/photo-1506665531195-3566af2b4dfa?w=800&q=80"
  ),
  new Destination(
    "d10",
    "c5",
    "Phuket",
    2200,
    1785,
    4.6,
    "Thailand's largest island featuring pristine beaches, crystal-clear waters, vibrant nightlife, and water sports. A tropical paradise for beach lovers.",
    "https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?w=800&q=80"
  ),

  // Egypt destinations
  new Destination(
    "d11",
    "c6",
    "Cairo",
    1600,
    969,
    4.2,
    "Ancient capital home to the Pyramids of Giza, Sphinx, and extensive Egyptian Museum collections. Gateway to one of the world's oldest civilizations.",
    "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=800&q=80"
  ),
  new Destination(
    "d12",
    "c6",
    "Luxor",
    1400,
    2100,
    4.4,
    "Open-air museum featuring the Valley of the Kings, Karnak Temple, and numerous pharaonic monuments. Often called the world's greatest museum.",
    "https://images.unsplash.com/photo-1591608971362-f08b2a75731a?w=800&q=80"
  ),

  // Australia destinations
  new Destination(
    "d13",
    "c7",
    "Sydney",
    4800,
    1788,
    4.7,
    "Iconic harbor city featuring the Opera House, Harbour Bridge, beautiful beaches, and vibrant cultural scene. Perfect blend of urban sophistication and natural beauty.",
    "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80"
  ),
  new Destination(
    "d14",
    "c7",
    "Melbourne",
    4200,
    1835,
    4.5,
    "Cultural capital known for coffee culture, street art, music scene, and diverse neighborhoods. Consistently ranked as one of the world's most livable cities.",
    "https://images.unsplash.com/photo-1514395462725-fb4566210144?w=800&q=80"
  ),

  // Brazil destinations
  new Destination(
    "d15",
    "c8",
    "Rio de Janeiro",
    2600,
    1565,
    4.6,
    "Marvelous city famous for Copacabana Beach, Christ the Redeemer statue, Carnival celebrations, and Sugar Loaf Mountain. Vibrant culture and stunning landscapes.",
    "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=800&q=80"
  ),
  new Destination(
    "d16",
    "c8",
    "Salvador",
    1900,
    1549,
    4.3,
    "Historic colonial city with Afro-Brazilian culture, colorful architecture, lively music scene, and beautiful beaches. UNESCO World Heritage site.",
    "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80"
  ),

  // Iceland destinations
  new Destination(
    "d17",
    "c9",
    "Reykjavik",
    5200,
    874,
    4.8,
    "Northernmost capital in the world, known for geothermal spas, Northern Lights, vibrant arts scene, and gateway to incredible natural wonders.",
    "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800&q=80"
  ),
  new Destination(
    "d18",
    "c9",
    "Blue Lagoon",
    3800,
    1976,
    4.7,
    "World-famous geothermal spa with milky blue waters rich in minerals. Surrounded by dramatic volcanic landscapes and offering ultimate relaxation.",
    "https://images.unsplash.com/photo-1682687220063-4742bd7fd538?w=800&q=80"
  ),

  // Morocco destinations
  new Destination(
    "d19",
    "c10",
    "Marrakech",
    1700,
    1070,
    4.4,
    "Imperial city known as the Red City, featuring bustling souks, stunning palaces, beautiful gardens, and the famous Jemaa el-Fnaa square.",
    "https://images.unsplash.com/photo-1597212618440-806262de4f6b?w=800&q=80"
  ),
  new Destination(
    "d20",
    "c10",
    "Casablanca",
    2100,
    768,
    4.2,
    "Modern economic capital featuring Hassan II Mosque, Art Deco architecture, bustling markets, and beautiful Atlantic coastline. Gateway to Morocco.",
    "https://images.unsplash.com/photo-1548013146-72479768bada?w=800&q=80"
  ),
];
