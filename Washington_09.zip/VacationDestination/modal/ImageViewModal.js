import {
  Modal,
  View,
  Button,
  Image,
  StyleSheet,
  Text,
  ScrollView,
} from "react-native";

function ImageViewModal(props) {
  return (
    <View style={styles.container}>
      <Modal
        visible={props.isVisible}
        animationType="slide"
        transparent={false}
      >
        <ScrollView contentContainerStyle={styles.modalContainer}>
          <Image style={styles.image} source={{ uri: props.imageUrl }} />
          <View style={styles.descriptionContainer}>
            <Text style={styles.description}>{props.description}</Text>
          </View>
          <Button title="Return to Destinations" onPress={props.onClose} />
        </ScrollView>
      </Modal>
    </View>
  );
}

export default ImageViewModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1e3a8a",
    padding: 20,
  },
  image: {
    width: "100%",
    height: 300,
    resizeMode: "cover",
    borderRadius: 10,
    marginBottom: 20,
  },
  descriptionContainer: {
    width: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: "center",
    color: "#333",
  },
});
