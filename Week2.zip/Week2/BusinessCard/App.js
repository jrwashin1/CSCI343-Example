import { StatusBar } from "expo-status-bar";
import { Linking, SafeAreaView, StyleSheet, Text, View, Image } from "react-native";

export default function App() {
  return (
    <>
    <StatusBar style="dark" />
    <SafeAreaView style={styles.root}>
      <View style={styles.imageContainer}>
        <Image 
          source={require("./assets/business_image.jpg")} 
          style={styles.image}
        />
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.name}>FAN ZONE</Text>
        <Text style={styles.text}
        onPress={ () => {Linking.openURL("https://www.thefanzone.com")}}> TheFanZone.com</Text>
        <Text style={styles.text}>(843)744-7742</Text>
        <Text style={styles.text}
        onPress={ () => {Linking.openURL("https://www.google.com/maps/search/?api=1&query=8437447742")}}> Open In Google Maps</Text>
      </View>
    </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2f387cff",
  },
  imageContainer: {
    flex: 2,
    justifyContent: "center",
    marginTop: 100,
    width: '100%',
  },
  image: {
    height: 200,
    width: '100%',
    resizeMode: "cover",
    borderColor: "black",
    borderWidth: 1,
  },
  textContainer: {
    flex: 3,
    width: '80%',
    alignItems: "center",  
  },
  text: {
    fontSize: 20,
    fontStyle: "italic",
    textAlign: "center",
    color: "#ffffff",
    marginBottom: 30,
  },

  name: {
    fontSize: 50,
    textAlign: "center",
    fontStyle: "italic",
    fontWeight: "bold",
    color: "#9c3a3aff",
    marginBottom: 90,
  }
});
