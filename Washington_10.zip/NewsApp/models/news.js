class News {
  constructor(
    id, // Unique number for each news article
    category, // Type of news: "US News", "World News", or "Tech News"
    headline, // Main title of the news article
    date, // When the article was published
    author, // Who wrote the article
    agency, // News agency (CNN, BBC, etc.)
    description, // Full text content of the article
    imageUrl // Web link to the article's image
  ) {
    // Store all the data as properties of this news object
    this.id = id;
    this.category = category;
    this.headline = headline;
    this.date = date;
    this.author = author;
    this.agency = agency;
    this.description = description;
    this.imageUrl = imageUrl;
  }

  // Method to convert news object to a readable string
  toString() {
    return `${this.headline} by ${this.author} from ${this.agency} on ${this.date} - Category: ${this.category} - Description: ${this.description} - Image URL: ${this.imageUrl}`;
  }
}

export default News;
