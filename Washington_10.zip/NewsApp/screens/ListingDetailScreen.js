import { StyleSheet, Text, View, Image } from "react-native";
import { NEWS } from "../data/dummy_data";
import { useLayoutEffect, useState } from "react";
import colors from "../constants/colors.js";

import BookmarkButton from "../components/BookmarkButton";

// Shows full details of a selected news article, while the param gets the news ID
export default function NewsDetailScreen(props) {
  const newsId = props.route.params.newsId;

  // Find the specific news article from our data using the ID
  const selectedNews = NEWS.find((news) => news.id === newsId);

  const [pressed, setPressed] = useState(false);

  function headerButtonPressHandler() {
    setPressed(!pressed);
  }

  useLayoutEffect(() => {
    props.navigation.setOptions({
      title: "",
      headerRight: () => {
        return (
          <BookmarkButton
            pressed={pressed}
            onPress={headerButtonPressHandler}
          />
        );
      },
    });
  }, [props.navigation, headerButtonPressHandler]);

  return (
    <View style={styles.rootContainer}>
      <View style={styles.imageContainer}>
        <Image style={styles.image} source={{ uri: selectedNews.imageUrl }} />
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.headline}>{selectedNews.headline}</Text>
        <Text style={styles.date}>{selectedNews.date}</Text>

        <Text style={styles.author}>By {selectedNews.author}</Text>

        <Text style={styles.agency}>{selectedNews.agency}</Text>
        <Text style={styles.description}>{selectedNews.description}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
  },
  imageContainer: {
    marginVertical: 10,
    height: 300,
  },
  image: {
    height: "100%",
    resizeMode: "cover",
    borderRadius: 7,
  },
  infoContainer: {
    borderRadius: 7,
    backgroundColor: colors.primary500o8,
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  headline: {
    color: colors.primary300,
    fontSize: 28,
    fontFamily: "playfairBold",
    paddingBottom: 10,
    textAlign: "center",
  },
  date: {
    color: colors.primary300,
    fontSize: 16,
    fontFamily: "playfair",
    paddingBottom: 10,
    fontStyle: "italic",
  },
  author: {
    color: colors.primary300,
    fontSize: 18,
    fontFamily: "playfair",
    paddingBottom: 5,
  },
  agency: {
    color: colors.primary300,
    fontSize: 16,
    fontFamily: "playfairBold",
    marginBottom: 20,
  },
  description: {
    color: colors.primary300,
    width: "100%",
    textAlign: "justify",
    fontSize: 15,
    fontFamily: "playfair",
    lineHeight: 22,
  },
});
