const Colors = {
  primary500: '#8B0000',
  accent: '#006400',
  cardBackground: '#fce5cd',
  textDark: '#333',
};

export default Colors;
