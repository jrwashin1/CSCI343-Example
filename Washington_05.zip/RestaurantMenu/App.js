import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet } from 'react-native';
import BaseScreen from './screens/BaseScreen';
import MenuScreen from './screens/MenuScreen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts } from 'expo-font';
import { ActivityIndicator, View } from 'react-native';
export default function App() {
  const [currentScreen, setCurrentScreen] = useState('base');

  // Load the custom restaurant font.
  const [fontsLoaded] = useFonts({
    Squealer: require('./assets/fonts/Squealer.otf'),
  });

  if (!fontsLoaded) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  function menuScreenHandler() {
    setCurrentScreen('menu');
  }

  function baseScreenHandler() {
    setCurrentScreen('base');
  }

  let screen = <BaseScreen onNext={menuScreenHandler} />;

  if (currentScreen === 'menu') {
    screen = <MenuScreen onNext={baseScreenHandler} />;
  }

  return (
    <>
      <StatusBar style="light" />
      <SafeAreaProvider style={styles.container}>{screen}</SafeAreaProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b38e80ff',
  },
});
