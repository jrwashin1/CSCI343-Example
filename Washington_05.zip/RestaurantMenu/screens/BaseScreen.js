import { StyleSheet, Text, View, Image, Button, Linking } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Title from '../components/Title';
import Colors from '../constants/colors';

export default function BaseScreen(props) {
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.rootContainer,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <View style={styles.titleContainer}>
        <Title>Gauchos Brazillian Steakhouse</Title>
      </View>

      <View style={styles.imageContainer}>
        <Image
          style={styles.image}
          source={require('../assets/images/restaurant.jpg')}
        />
      </View>

      <View style={styles.infoContainer}>
        <Text
          style={styles.infoText}
          onPress={() => Linking.openURL('tel:843-123-9876')}
        >
          (843) 123-9876
        </Text>

        <Text
          style={styles.infoText}
          onPress={() =>
            Linking.openURL(
              'https://maps.app.goo.gl/PNiQfiAtkY25QWhe9'
            )
          }
        >
          6429 N Kings Hwy, Myrtle Beach, SC 29572
        </Text>

        <Text
          style={styles.infoText}
          onPress={() => Linking.openURL('https://www.gauchosusa.com')}
        >
          www.gauchosusa.com
        </Text>
      </View>

      <View style={styles.buttonContainer}>
        <Button title="View Menu" color={Colors.primary500} onPress={props.onNext} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  imageContainer: {
    flex: 4,
  },
  image: {
    resizeMode: 'cover',
    height: '100%',
    width: 300,
    borderRadius: 15,
  },
  infoContainer: {
    flex: 3,
    justifyContent: 'center',
  },
  infoText: {
    fontSize: 20,
    textAlign: 'center',
    padding: 7,
    color: Colors.textDark,
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    width: 150,
  },
});
