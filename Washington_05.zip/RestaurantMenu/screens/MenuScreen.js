import { FlatList, StyleSheet, View, Button } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Title from '../components/Title';
import MenuItem from '../components/MenuItem';
import Colors from '../constants/colors';
import { useState } from 'react';

export default function MenuScreen(props) {
  const insets = useSafeAreaInsets();

  const [menuItems, setMenuItems] = useState([
    { id: 1, name: 'Shrimp', image: require('../assets/images/shrimp.jpg'), price: '$18.99' },
    { id: 2, name: 'Spaghetti Carbonara', image: require('../assets/images/pasta.jpg'), price: '$14.99' },
    { id: 3, name: 'Caesar Salad', image: require('../assets/images/salad.jpg'), price: '$9.99' },
    { id: 4, name: 'Filet Mignon', image: require('../assets/images/filet.jpg'), price: '$36.99' },
    { id: 5, name: 'Steak', image: require('../assets/images/steak.jpg'), price: '$24.99' },
  ]);

  return (
    <View
      style={[
        styles.rootContainer,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <View style={styles.titleContainer}>
        <Title>Our Menu</Title>
      </View>

      <View style={styles.listContainer}>
        <FlatList
          data={menuItems}
          keyExtractor={(item) => item.id.toString()}
          renderItem={(itemData) => {
            return (
              <MenuItem
                name={itemData.item.name}
                image={itemData.item.image}
                price={itemData.item.price}
              />
            );
          }}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="Back to Home" color={Colors.primary500} onPress={props.onNext} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  listContainer: {
    flex: 7,
    width: 380,
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    width: 180,
  },
});
