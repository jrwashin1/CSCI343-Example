import { Image, View, StyleSheet, Text } from 'react-native';
import Colors from '../constants/colors';

export default function MenuItem(props) {
  return (
    <View style={styles.itemContainer}>
      <Text style={styles.title}>{props.name}</Text>
      <View style={styles.imageContainer}>
        <Image style={styles.image} source={props.image} />
      </View>
      <Text style={styles.price}>{props.price}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  itemContainer: {
    marginBottom: 20,
    padding: 10,
    borderWidth: 2,
    borderColor: Colors.primary500,
    borderRadius: 10,
    backgroundColor: Colors.cardBackground,
  },
  title: {
    fontSize: 22,
    textAlign: 'center',
    marginBottom: 5,
    color: Colors.textDark,
  },
  imageContainer: {
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: 175,
    resizeMode: 'cover',
    borderRadius: 10,
  },
  price: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 8,
    color: Colors.accent,
  },
});
