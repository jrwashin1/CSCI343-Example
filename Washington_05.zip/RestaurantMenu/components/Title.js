import { StyleSheet, Text } from 'react-native';
import Colors from '../constants/colors';

export default function Title(props) {
  return <Text style={styles.title}>{props.children}</Text>;
}

const styles = StyleSheet.create({
  title: {
    fontSize: 25,
    fontFamily: 'Squealer',
    color: Colors.textDark,
    marginBottom: 20,
    textAlign: 'center',
  },
});
